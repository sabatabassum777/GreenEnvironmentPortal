import java.awt.*;
import java.lang.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.EventQueue;
import java.awt.Image;
import java.lang.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableModel;
import java.util.*;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.io.*;
public class Home {

	private JFrame frmHrapHomeoClinic;

	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args)throws IOException,NullPointerException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home window = new Home();
					window.frmHrapHomeoClinic.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the application.
	 */
	public Home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frmHrapHomeoClinic = new JFrame();
		//frmHrapHomeoClinic.getContentPane().setBackground(Color.GREEN);
		frmHrapHomeoClinic.getContentPane().setBackground(new Color(34,139,34));
		frmHrapHomeoClinic.getContentPane().setForeground(Color.WHITE);
		frmHrapHomeoClinic.setTitle("HOME PAGE");
		frmHrapHomeoClinic.setBounds(100, 100, 845, 888);
		//frmHrapHomeoClinic.setBounds(100, 100, 700, 453);
		frmHrapHomeoClinic.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmHrapHomeoClinic.getContentPane().setLayout(null);
		frmHrapHomeoClinic.setVisible(true);
		
		JLabel label = new JLabel(); //JLabel Creation
        label.setIcon(new ImageIcon("javap11.jpg")); //Sets the image to be displayed as an icon 
        label.setBounds(250, 70, 256,256);
		//Sets the location of the image
 
    	frmHrapHomeoClinic.getContentPane().add(label);//Adds objects to the container
        frmHrapHomeoClinic.setVisible(true); // Exhibit the frame


		JLabel lblNewLabel_1 = new JLabel("  NURSERY PORTAL");
		lblNewLabel_1.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel_1.setBounds(174, 11, 350, 55);
		frmHrapHomeoClinic.getContentPane().add(lblNewLabel_1);
		JButton Update=new JButton();
		JButton Submit=new JButton();
		JButton Refresh=new JButton();
		JButton Import=new JButton();
		JButton btnNewButton = new JButton("Nursery");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmHrapHomeoClinic = new JFrame("HRAP HOMEO CLINIC");
				frmHrapHomeoClinic.getContentPane().setBackground(new Color(107,142,35));
				//frmHrapHomeoClinic.getContentPane().setBackground(Color.GREEN);
				frmHrapHomeoClinic.getContentPane().setForeground(Color.WHITE);
				frmHrapHomeoClinic.setBounds(100, 100, 845, 888);
				frmHrapHomeoClinic.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frmHrapHomeoClinic.getContentPane().setLayout(null);
				frmHrapHomeoClinic.setVisible(true);
				JTextArea textArea = null;
				JLabel PlantLabel,QuantityLabel,PriceLabel,jl1;
				JTextField PtextFiled,QtextField,PrtextField;
				JButton Submit,Refresh,Update;
				jl1=new JLabel("WELCOME TO Nursery Management");//HOMEPAGE STARTS
    			jl1.setFont(new Font("Verdana",Font.BOLD,30));
    			jl1.setBounds(150,0,650,150);
    			frmHrapHomeoClinic.add(jl1);
				PlantLabel=new JLabel("Plant Name");
				PlantLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
				PlantLabel.setBounds(98, 400, 150, 50);
				frmHrapHomeoClinic.getContentPane().add(PlantLabel);
		
				QuantityLabel = new JLabel("Quantity");
				QuantityLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
				QuantityLabel.setBounds(98, 500, 150 , 50);
				frmHrapHomeoClinic.getContentPane().add(QuantityLabel);
		
				PriceLabel = new JLabel("Price");
				PriceLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
				PriceLabel.setBounds(98, 600, 150, 50);
				frmHrapHomeoClinic.getContentPane().add(PriceLabel);
				

				PtextFiled = new JTextField();
				PtextFiled.setBounds(300, 400, 150, 50);
				frmHrapHomeoClinic.getContentPane().add( PtextFiled);
				PtextFiled.setColumns(10);
				
				QtextField= new JTextField();
				QtextField.setColumns(10);
				QtextField.setBounds(300, 500, 150, 50);
				frmHrapHomeoClinic.getContentPane().add(QtextField);
				
				PrtextField = new JTextField();
				PrtextField.setColumns(10);
				PrtextField.setBounds(300, 600, 150, 50);
				frmHrapHomeoClinic.getContentPane().add(PrtextField);
				
				Submit=new JButton("Submit");
				Submit.setBounds(200,700,120,50);
				frmHrapHomeoClinic.getContentPane().add(Submit);
				Submit.setForeground(Color.BLACK);
				Submit.setBackground(Color.PINK);
				Submit.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ae)
					{
						try
                                            {
                                                int i=0;
                                                String filePath = "PlantList.txt";
                                                FileWriter fw = new FileWriter(filePath, true);    
                                                String lineToAppend ="\nplant_name:"+PtextFiled.getText()+"\tQuantity:"+QtextField.getText()+"\tPrice:"+PrtextField.getText() ;
                                                fw.write(lineToAppend);
                                                i++;
                                                fw.close();
                                        
                                            }
                                            catch(Exception e)
                                            {
                                                System.out.println(e);
                                            }
											JOptionPane.showMessageDialog(null, "Successful!!");    
					}
				});
				Update=new JButton("Update");
				Update.setBounds(400,700,120,50);
				frmHrapHomeoClinic.getContentPane().add(Update);
				Update.setForeground(Color.BLACK);
				Update.setBackground(Color.PINK);
				Update.addActionListener(new ActionListener(){   
					public void actionPerformed(ActionEvent ae){
						JTable jTable1=new JTable();
						JTable jTable2=new JTable();
						String filepath="PlantList.txt";
						try{
						File file=new File(filepath);
						FileReader fr=new FileReader(file);
						BufferedReader br=new BufferedReader(fr);
						DefaultTableModel model=(DefaultTableModel)jTable2.getModel();
						Object[] lines=br.lines().toArray();
						for(int i=0;i<lines.length;i++)
						{
							String[] row=lines[i].toString().split(" ");
							model.addRow(row);
						}
						}
						catch(Exception e)
						{
							System.out.println(e);
						}
						if(PtextFiled.getText().equals("")||QtextField.getText().equals("")||PrtextField.getText().equals(""))
						{
							JOptionPane.showMessageDialog(null,"Please Enter All Data");
						}
						else{
							String data[]={PtextFiled.getText(),QtextField.getText(),PrtextField.getText()};
							String column[]={"Name","Quantity","Price"};
							DefaultTableModel tb1Model=(DefaultTableModel)jTable1.getModel();
							tb1Model.addRow(data);
							tb1Model.addColumn(column);
							jTable1.setBounds(30,40,200,300);          
							JScrollPane sp=new JScrollPane(jTable1);    
							frmHrapHomeoClinic.getContentPane().add(sp);
							
							JOptionPane.showMessageDialog(null, "Successful!!");
							PtextFiled.setText("");
							QtextField.setText("");
							PrtextField.setText("");
						}	
					}});
				
				Refresh=new JButton("Refresh");
				Refresh.setBounds(600,700,120,50);
				frmHrapHomeoClinic.getContentPane().add(Refresh);
				Refresh.setForeground(Color.BLACK);
				Refresh.setBackground(Color.PINK);
				Refresh.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ae)
					{
						PtextFiled.setText("");
						QtextField.setText("");
						PrtextField.setText("");
						//add back option
					}
				});
				//JTable


			}
		});
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setBounds(110, 322, 175, 42);
		frmHrapHomeoClinic.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("DOCTOR'S LOGIN");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmHrapHomeoClinic = new JFrame("HRAP HOMEO CLINIC");
				frmHrapHomeoClinic.getContentPane().setBackground(new Color(152,251,152));
				frmHrapHomeoClinic.getContentPane().setForeground(Color.WHITE);
				frmHrapHomeoClinic.setBounds(100, 100, 500, 500);
				frmHrapHomeoClinic.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frmHrapHomeoClinic.getContentPane().setLayout(null);
				frmHrapHomeoClinic.setVisible(true);
				JTextArea textArea = null;
				JTextField userField;
				JPasswordField pswdField;
				JLabel userLabel,pswdLabel;
				JButton submit;
				userLabel=new JLabel("Username");
				userLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
				userLabel.setBounds(98, 100, 150, 50);
				frmHrapHomeoClinic.getContentPane().add(userLabel);
		
				pswdLabel = new JLabel("Password");
				pswdLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
				pswdLabel.setBounds(98, 200, 150 , 50);
				frmHrapHomeoClinic.getContentPane().add(pswdLabel);

				userField = new JTextField();
				userField.setBounds(250, 100, 150, 50);
				frmHrapHomeoClinic.getContentPane().add( userField);
				
				pswdField= new JPasswordField();
				pswdField.setColumns(10);
				pswdField.setBounds(250, 200, 150, 50);
				frmHrapHomeoClinic.getContentPane().add(pswdField);
				
				submit=new JButton("Submit");
				submit.setForeground(Color.BLACK);
				submit.setBackground(Color.PINK);
				submit.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
				submit.setBounds(120, 322, 175, 42);
				frmHrapHomeoClinic.getContentPane().add(submit);
		
				submit.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ae)
					{
						try{
							int flag=0;
							String username=userField.getText();
							String password = String.valueOf(pswdField.getPassword());
							FileInputStream fs=new FileInputStream("1pswd.txt");
							Scanner sc2 = new Scanner(fs);
                          while(sc2.hasNextLine()) {
                            //.hasNextLine checks their is another line same as input Scanner
                            String line = sc2.nextLine();//storing that into line
                            if(line.indexOf(password)!=-1) {
                                //.indexOf return the first occurence of characterin string
                               JOptionPane.showMessageDialog(null, "Welcome Doctor "+username);
                               flag=1;
                            }
                            else{
								JOptionPane.showMessageDialog(null,"Your Not Allowed!!");
                            }
									}
								}
								catch(Exception e)
								{
									System.out.println(e);
								}

							// new page
							frmHrapHomeoClinic = new JFrame("HRAP HOMEO CLINIC");
							frmHrapHomeoClinic.getContentPane().setBackground(new Color(255,153,255));
							frmHrapHomeoClinic.getContentPane().setForeground(Color.WHITE);
							frmHrapHomeoClinic.setBounds(100, 100, 500, 500);
							frmHrapHomeoClinic.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
							frmHrapHomeoClinic.getContentPane().setLayout(null);
							frmHrapHomeoClinic.setVisible(true);
							JTextArea textArea = null;
							JButton b1,b2,b3;
							b1=new JButton("Patient's List");
							b1.setFont(new Font("Tahoma", Font.BOLD, 20));
							b1.setBounds(98, 100, 200, 50);
							b1.setForeground(Color.BLACK);
							b1.setBackground(new Color(255,153,204));
							frmHrapHomeoClinic.getContentPane().add(b1);
					
							b2=new JButton("Health History");
							b2.setFont(new Font("Tahoma", Font.BOLD, 20));
							b2.setBounds(98, 200, 200 , 50);
							b2.setForeground(Color.BLACK);
							b2.setBackground(new Color(255,153,204));
							frmHrapHomeoClinic.getContentPane().add(b2);
							
							b3=new JButton("Prescrption");
							b3.setFont(new Font("Tahoma", Font.BOLD, 20));
							b3.setBounds(98, 300, 200 , 50);
							b3.setForeground(Color.BLACK);
							b3.setBackground(new Color(255,153,204));
							frmHrapHomeoClinic.getContentPane().add(b3);

							b3.addActionListener(new ActionListener(){
								public void actionPerformed(ActionEvent ae)
								{
									frmHrapHomeoClinic = new JFrame("HRAP HOMEO CLINIC");
				frmHrapHomeoClinic.getContentPane().setBackground(new Color(255,102,178));
				//frmHrapHomeoClinic.getContentPane().setBackground(Color.GREEN);
				frmHrapHomeoClinic.getContentPane().setForeground(Color.WHITE);
				frmHrapHomeoClinic.setBounds(100, 100, 845, 888);
				frmHrapHomeoClinic.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frmHrapHomeoClinic.getContentPane().setLayout(null);
				frmHrapHomeoClinic.setVisible(true);
				JTextArea textArea = null;
				JLabel idLabel,diseaseLabel,medLabel,jl1;
				JTextField ja1,ja2,ja3;
				JButton Submit,Refresh,Update;
				jl1=new JLabel("Prescription For Patients!!");//HOMEPAGE STARTS
    			jl1.setFont(new Font("Verdana",Font.BOLD,30));
    			jl1.setBounds(150,0,650,150);
    			frmHrapHomeoClinic.add(jl1);
				idLabel=new JLabel("Plant ID");
				idLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
				idLabel.setBounds(98, 400, 150, 50);
				frmHrapHomeoClinic.getContentPane().add(idLabel);
		
				diseaseLabel = new JLabel("Disease");
				diseaseLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
				diseaseLabel.setBounds(98, 500, 150 , 50);
				frmHrapHomeoClinic.getContentPane().add(diseaseLabel);
		
				medLabel = new JLabel("Medicine");
				medLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
				medLabel.setBounds(98, 600, 150, 50);
				frmHrapHomeoClinic.getContentPane().add(medLabel);
				

				ja1 = new JTextField();
				ja1.setBounds(300, 400, 150, 50);
				frmHrapHomeoClinic.getContentPane().add( ja1);
				ja1.setColumns(10);
				
				ja2= new JTextField();
				ja2.setColumns(10);
				ja2.setBounds(300, 500, 150, 50);
				frmHrapHomeoClinic.getContentPane().add(ja2);
				
				ja3 = new JTextField();
				ja3.setColumns(10);
				ja3.setBounds(300, 600, 150, 50);
				frmHrapHomeoClinic.getContentPane().add(ja3);
				
				Submit=new JButton("Submit");
				Submit.setBounds(200,700,120,50);
				frmHrapHomeoClinic.getContentPane().add(Submit);
				Submit.setForeground(Color.BLACK);
				Submit.setBackground(Color.BLUE);
				Submit.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ae)
					{
						try
                                                {
                                                String filePath = "Prescription.txt";
                                                FileWriter fw = new FileWriter(filePath, true);    
                                                String lineToAppend ="\nPlant_ID:"+ja1.getText()+"\tDisease:"+ja2.getText()+"\tMedicine:"+ja3.getText() ;
                                                fw.write(lineToAppend);
                                                fw.close();
                                                }
                                                catch(Exception e)
                                                {
                                                    System.out.println(e);
                                                } 
											JOptionPane.showMessageDialog(null, "Successful!!");    
					}
				});

								}
							});
				
							}
				});
				
			}
		});
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1.setBounds(403, 321, 185, 44);
		frmHrapHomeoClinic.getContentPane().add(btnNewButton_1);
	}
}

