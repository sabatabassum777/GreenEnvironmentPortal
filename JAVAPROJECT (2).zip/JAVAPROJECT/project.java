// Green Environment portal for Botanist and doctors.
import java.util.*;
import java.io.*;  
class add implements Serializable{
    String pname;
    double q;
    int price;
} 
class Nursery implements Serializable
{
    double quantity;
    int Price;
    Nursery(){
        quantity=0;
        Price=0;
    }
    void Add(String pname,double d,int price)
    {
        this.quantity+=d;
        this.Price+=price;
        System.out.println("Plant name: "+pname);
        System.out.println("Quantity: "+quantity);
        System.out.println("Price: "+price);
        System.out.println("Plant Added!!!");
    }
    void Sell(String pname,double d)
    {
        this.quantity=this.quantity-d;
        System.out.println("Sold!!!");
    }
    void discount(String pname,int d)
    {
        this.Price=this.Price-d;
    }
    double available(){
        return this.quantity;
    }
    int price()
    {
        return this.Price;
    }
}
class Nursery1 extends Nursery{//plant care
    String name;
}
class Nursery2 extends Nursery{
    String campaign;
}
class Doctor
{
    void doctor()
    {
        System.out.println("Iam Doctor");
    }
}
class project{
    public static void main(String args[])throws IOException,ClassNotFoundException,InvalidClassException
    {
        //Enter the choice 
        System.out.println("Enter Your Choice");
        System.out.println("1. Nursery    2.Doctor's  3.Exit");
        System.out.print("Enter:");
        Scanner sc=new Scanner(System.in);
        //for 1. Nursery or 2.Doctor
        int x=sc.nextInt();
        Nursery n=new Nursery();
        Nursery1 n1=new Nursery1();
        Nursery2 n2=new Nursery2();
       Doctor d=new Doctor();
            switch(x)
            {
                    case 1:
                            System.out.println("Enter Your Choice:");
                            System.out.println("1. Nursery Management\n2. Plant Health Care\n3. Plant Campaigns ");
                            System.out.println("Enter:");
                            int y=sc.nextInt();
                            int count=0;
                            do{
                            switch(y)
                            {
                                case 1: 
                                    System.out.println("Welcome to Nursery Management!!!");
                                    System.out.println("1.Add\n2.Sell\n3.Discounts\n4.Avaliability\n5.Exit");
                                    System.out.print("Enter:");
                                    int z=sc.nextInt();
                                    switch(z)
                                    {
                                         case 1:
                                            Console  c=System.console();
                                            System.out.print("Enter the Plant name:");
                                            String pname1=c.readLine();
                                            System.out.print("Enter Quantity:");
                                            double q1=sc.nextInt();
                                            System.out.print("Enter Price:");
                                            int price1=sc.nextInt();
                                            n.Add(pname1,q1,price1);
                                            //adding into file add.txt
                                            FileOutputStream fs=new FileOutputStream("ADD.txt");
                                            ObjectOutputStream os=new ObjectOutputStream(fs);
                                            add obj=new add();
                                            obj.pname=pname1;
                                            obj.q=n.available();
                                            obj.price=n.price();
                                            os.writeObject(obj);
                                            fs.close();
                                            os.close();
                                            count=0;
                                            break;
                                        case 2:
                                            Console  c1=System.console();
                                            System.out.print("Enter the Plant name:");
                                            String sname=c1.readLine();
                                            System.out.print("Enter Quantity:");
                                            int sq=sc.nextInt();
                                            double b=n.available();
                                            n.Sell(sname,sq);
                                            //adding into file add.txt //only one instance
                                            FileOutputStream fs1=new FileOutputStream("ADD.txt");
                                            ObjectOutputStream os1=new ObjectOutputStream(fs1);
                                            add obj1=new add();
                                            obj1.pname=sname;
                                            obj1.q=n.available();
                                            obj1.price=n.price();
                                            os1.writeObject(obj1);
                                            fs1.close();
                                            os1.close();
                                            System.out.print("Solded\n");
                                            count=0;
                                            break;
                                        case 3:
                                            Console  c2=System.console();
                                            System.out.print("Enter the Plant name:");
                                            String dname=c2.readLine();
                                            System.out.print("Enter Discount price:");
                                            int dprice=sc.nextInt();
                                            n.discount(dname,dprice);
                                            //adding into ADD.txt only one item at a time
                                            FileOutputStream fs2=new FileOutputStream("ADD.txt");
                                            ObjectOutputStream os2=new ObjectOutputStream(fs2);
                                            add obj2=new add();
                                            obj2.pname=dname;
                                            obj2.q=n.available();
                                            obj2.price=n.price();
                                            os2.writeObject(obj2);
                                            fs2.close();
                                            os2.close();
                                            count=0;
                                            break;
                                        case 4:
                                            System.out.println("---------Available List Of Plants----------\n");
                                            double b1=n.available();
                                            int p=n.price();
                                            System.out.print("Available plants "+b1+"\n");
                                            System.out.println("Price of each item  "+p+"\n");
                                            FileInputStream fr= new FileInputStream("ADD.txt");
                                            ObjectInputStream o=new ObjectInputStream(fr);
                                            add obj3=new add();
                                            obj3=(add)o.readObject();
                                            System.out.println("Plant name: "+obj3.pname);
                                            System.out.println("Available quantity: "+obj3.q);
                                            System.out.println("Price Of Plant: "+obj3.price);
                                            try
                                            {
                                                int i=0;
                                                String filePath = "PlantList.txt";
                                                FileWriter fw = new FileWriter(filePath, true);    
                                                String lineToAppend ="\nplant_name:"+obj3.pname+"\tQuantity:"+obj3.q+"\tPrice:"+obj3.price ;
                                                fw.write(lineToAppend);
                                                i++;
                                                fw.close();
                                        
                                            }
                                            catch(Exception e)
                                            {
                                                System.out.println(e);
                                            }       
                                            fr.close();
                                            o.close();
                                            count=0;
                                            break;
                                        case 5:
                                                System.out.println("-----------EXIT--------------\n");
                                                count=1;
                                                break;
                                    }

                                    if(count==1)
                                    break;
                                    

                                break;
                                case 2://plant Care section-2---
                                        System.out.println("1.Add Disease \n2.Disease Care\n3.Book a Doctor\n4.exit");
                                        int r,countc=0;
                                        Console  c2=System.console();
                                        System.out.println("Enter Your Choice:\n");
                                        r=sc.nextInt();
                                        switch(r){
                                            case 1:
                                                //Adding disease details to file
                                                System.out.println("Enter The Disease Of Plant:\n");
                                                String disease_name=c2.readLine();
                                                System.out.println("Enter The Symptoms:\n");
                                                String symptom_name=c2.readLine();
                                                System.out.println("Enter The Pesticides for cure\n");
                                                String cure=c2.readLine();
                                                try
                                                {
                                                String filePath = "Disease.txt";
                                                FileWriter fw = new FileWriter(filePath, true);    
                                                String lineToAppend ="\nDisease_name:"+disease_name+"\tSymptom:"+symptom_name+"\tPesticide:"+cure ;
                                                fw.write(lineToAppend);
                                                fw.close();
                                                }
                                                catch(Exception e)
                                                {
                                                    System.out.println(e);
                                                }       
                                                countc=0;
                                            break;
                                            case 2:
                                                //Disease Care
                                                System.out.println("----------Welcome To Disease Care!!!-----------");
                                                System.out.println("Enter the Disease:\n");
                                                Console c4=System.console();
                                                String disease1_name=c4.readLine();
                                                Scanner sc2 = new Scanner(new FileInputStream("Disease.txt"));
                                                while(sc2.hasNextLine()) {
                                                    //.hasNextLine checks their is another line same as input Scanner
                                                    String line = sc2.nextLine();//storing that into line
                                                    if(line.indexOf(disease1_name)!=-1) {
                                                        //.indexOf return the first occurence of characterin string
                                                       System.out.println(line);
                                                    }
                                                 }
                                                sc2.close();
                                                countc=0;
                                            break;
                                            case 3:
                                                System.out.println("-----------Welcome to Booking Section!!-------- ");
                                                int ID;//id should be of your chose given to identify your plant.
                                                System.out.println("Enter Plant ID:");
                                                ID=sc.nextInt();
                                                System.out.println("Book Your Doctor Here");
                                                System.out.println("1.Dr.Naresh\n2.Dr.Radika\n3.Dr.Ramesh\n4.exit");
                                                System.out.println("Enter Your Choice:\n");
                                                int ch2=sc.nextInt();
                                                switch(ch2)
                                                {
                                                    case 1:
                                                        try
                                                        {
                                                            int i=1;
                                                            String filePath = "1.txt";
                                                            FileWriter fw = new FileWriter(filePath, true);    
                                                            String lineToAppend ="\nPlant_ID:"+ID+"\tRegno:"+i;
                                                            fw.write(lineToAppend);
                                                            i++;
                                                            fw.close();
                                                        }
                                                        catch(Exception e)
                                                        {
                                                            System.out.println(e);
                                                        }      
                                                            System.out.println("--------Appointment Booked!!--------\n");
                                                            countc=0;
                                                    break;
                                                    case 2:
                                                        try
                                                        {
                                                            int i=1;
                                                            String filePath = "2.txt";
                                                            FileWriter fw = new FileWriter(filePath, true);    
                                                            String lineToAppend ="\nPlant_ID:"+ID+"\tRegno:"+i;
                                                            i++;
                                                            fw.write(lineToAppend);
                                                            fw.close();
                                                        }
                                                        catch(Exception e)
                                                        {
                                                            System.out.println(e);
                                                        }      
                                                            System.out.println("--------Appointment Booked!!--------\n");
                                                            countc=0;
                                                    break;
                                                    case 3:
                                                        try
                                                        {
                                                            int i=1;
                                                            String filePath = "3.txt";
                                                            FileWriter fw = new FileWriter(filePath, true);    
                                                            String lineToAppend ="\nPlant_ID:"+ID+"\tRegno:"+i++;
                                                            fw.write(lineToAppend);
                                                            fw.close();
                                                        }
                                                        catch(Exception e)
                                                        {
                                                            System.out.println(e);
                                                        }      
                                                            System.out.println("--------Appointment Booked!!--------\n");
                                                            countc=0;
                                                    break;
                                                    case 4:
                                                        System.out.println("-----------EXIT--------------\n");
                                                        countc=1;
                                                        break;


                                            }
                                                    if(countc==1)
                                                        break; 
                                            break;
                                            case 4:
                                                    System.out.println("-----------EXIT--------------\n");
                                                    countc=1;
                                                    break;
                                            
                                        }
                                        if(countc==1)
                                            break;
                                    break;
                                case 3:
                                        //campaigns
                                        int c,cc=0;
                                        System.out.println("-----------Welcome To Green Campaigns-------------\n");
                                        System.out.println("1.Add Campaign\n2.Display Campaigns");
                                        System.out.println("Enter Your choice:");
                                        c=sc.nextInt();
                                        switch(c){
                                            case 1:
                                                Console  c4=System.console();
                                                System.out.println("Enter Campaign:");
                                                String campaign1=c4.readLine();
                                                try
                                                        {
                                                            int i=1;
                                                            String filePath = "campaign1.txt";
                                                            FileWriter fw = new FileWriter(filePath, true);    
                                                            String lineToAppend ="\nCampaign:"+campaign1+"\tRegno:"+i;
                                                            fw.write(lineToAppend);
                                                            i++;
                                                            fw.close();
                                                        }
                                                        catch(Exception e)
                                                        {
                                                            System.out.println(e);
                                                        }
                                                cc=0;
                                            break;
                                            case 2:
                                                    try  
                                                    {  
                                                    //the file to be opened for reading  
                                                    FileInputStream fis=new FileInputStream("campaign1.txt");       
                                                    Scanner sc1=new Scanner(fis);    //file to be scanned  
                                                    //returns true if there is another line to read  
                                                    while(sc1.hasNextLine())  
                                                    {  
                                                    System.out.println(sc1.nextLine());
                                                    }  
                                                    sc1.close();   
                                                    }  
                                                    catch(IOException e)  
                                                    {  
                                                        System.out.println(e);
                                                    }  
                                                    cc=0;
                                            break;
                                            case 3:
                                                    System.out.println("-----------EXIT--------------\n");
                                                    cc=1;
                                                    break;
                                        }
                                        if(cc==1)
                                            break;
                                        
                            }
                            }while(count==0);
                        break;
                    case 2:
                          int flag=1,c=0;
                          System.out.println("---------Welcome Doctors------")  ;
                          Console  doc=System.console();
                          System.out.println("Enter Your Name:/n");
                          String name=doc.readLine();
                          System.out.println("Enter Login Password:\n");
                          String pswd=doc.readLine();
                          Scanner sc2 = new Scanner(new FileInputStream("1pswd.txt"));
                          while(sc2.hasNextLine()) {
                            //.hasNextLine checks their is another line same as input Scanner
                            String line = sc2.nextLine();//storing that into line
                            if(line.indexOf(pswd)!=-1) {
                                //.indexOf return the first occurence of characterin string
                               System.out.println("Welcome Doctor "+name);
                               flag=1;
                            }
                            else{
                                System.out.println("Only Doctor's Portal Your Not Allowed!!");
                            }
                            
                            do{
                            if(flag==1)
                            {
                                int x1;
                                System.out.println("\n1.Patients List\n2.Health History\n3.Prescription");
                                System.out.println("Enter Your Choice:");
                                x1=sc.nextInt();
                                switch(x1)
                                {
                                    case 1:
                                        System.out.println("---------------Patients List \n-------------------");
                                        String d1=new String("Naresh");
                                        String d2=new String("Radika");
                                        String d3=new String("Ramesh");
                                        if(name.equals(d1))
                                        {
                                                try  
                                                    {  
                                                    //the file to be opened for reading  
                                                    FileInputStream fis=new FileInputStream("1.txt");       
                                                    Scanner sc1=new Scanner(fis);    //file to be scanned  
                                                    //returns true if there is another line to read  
                                                    while(sc1.hasNextLine())  
                                                    {  
                                                    System.out.println(sc1.nextLine());
                                                    }  
                                                    sc1.close();   
                                                    }  
                                                    catch(IOException e)  
                                                    {  
                                                        System.out.println(e);
                                                    } 
                                                    c=0; 
                                        }
                                        if(name.equals(d2))
                                        {
                                                try  
                                                    {  
                                                    //the file to be opened for reading  
                                                    FileInputStream fis=new FileInputStream("2.txt");       
                                                    Scanner sc1=new Scanner(fis);    //file to be scanned  
                                                    //returns true if there is another line to read  
                                                    while(sc1.hasNextLine())  
                                                    {  
                                                    System.out.println(sc1.nextLine());
                                                    }  
                                                    sc1.close();   
                                                    }  
                                                    catch(IOException e)  
                                                    {  
                                                        System.out.println(e);
                                                    } 
                                                    c=0; 
                                        }
                                        if(name.equals(d3))
                                        {
                                                try  
                                                    {  
                                                    //the file to be opened for reading  
                                                    FileInputStream fis=new FileInputStream("3.txt");       
                                                    Scanner sc1=new Scanner(fis);    //file to be scanned  
                                                    //returns true if there is another line to read  
                                                    while(sc1.hasNextLine())  
                                                    {  
                                                    System.out.println(sc1.nextLine());
                                                    }  
                                                    sc1.close();   
                                                    }  
                                                    catch(IOException e)  
                                                    {  
                                                        System.out.println(e);
                                                    } 
                                                    c=0; 
                                        }
                                        c=0;
                                    break;
                                    case 2:
                                            System.out.println("Health History of Plant\n");
                                            System.out.println("Enter Plant_ID:");
                                            Console c5=System.console();
                                                String ID=c5.readLine();
                                                Scanner sc4 = new Scanner(new FileInputStream("Prescription.txt"));
                                                while(sc4.hasNextLine()) {
                                                    //.hasNextLine checks their is another line same as input Scanner
                                                    String line2 = sc4.nextLine();//storing that into line
                                                    if(line2.indexOf(ID)!=-1) {
                                                        //.indexOf return the first occurence of characterin string
                                                       System.out.println(line2);
                                                    }
                                                 }
                                                sc4.close();
                                                c=0;
                                    break;
                                    case 3:
                                            System.out.println("Prescription\n");
                                            System.out.println("Enter Plant_ID:");
                                            Console c4=System.console();
                                            String ID1=c4.readLine();
                                            System.out.println("Enter The Disease:");
                                            String disease1_name=c4.readLine();
                                            System.out.println("Enter Medicine:");
                                            String cure=c4.readLine();
                                            try
                                                {
                                                String filePath = "Prescription.txt";
                                                FileWriter fw = new FileWriter(filePath, true);    
                                                String lineToAppend ="\nPlant_ID:"+ID1+"\tDisease:"+disease1_name+"\tMedicine:"+cure ;
                                                fw.write(lineToAppend);
                                                fw.close();
                                                }
                                                catch(Exception e)
                                                {
                                                    System.out.println(e);
                                                } 
                                                c=0;
                                    break;
                                    case 4:
                                    System.out.println("-----------EXIT--------------\n");
                                    c=1;
                                    break;
                                }
                                if(c==1)
                                break;
                            }
                            }while(c==0);
                            sc2.close();
                        }
                    break;
                    case 3:
                            System.out.println("---------------EXIT--------------\n");
                            System.exit(0);
                            break;
            }

    }
}